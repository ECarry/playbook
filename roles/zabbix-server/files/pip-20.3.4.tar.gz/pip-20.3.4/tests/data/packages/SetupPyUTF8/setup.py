# -*- coding: utf-8 -*-

from distutils.core import setup

setup(name="SetupPyUTF8",
      author="Saúl Ibarra Corretgé",
      )
